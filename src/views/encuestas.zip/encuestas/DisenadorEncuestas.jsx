import React from 'react'

const DisenadorEncuestas = () => {
  return (
    <div>
        <h1>Disenador Encuestas</h1>
    </div>
  )
}

export default DisenadorEncuestas
 