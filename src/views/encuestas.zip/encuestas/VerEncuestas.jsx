import React from 'react'

const VerEncuestas = () => {
  return (
    <div>
        <h1>Ver Encuestas</h1>
    </div>
  )
}

export default VerEncuestas
